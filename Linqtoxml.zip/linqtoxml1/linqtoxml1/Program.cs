﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace linqtoxml1
{
    class Program
    {
       static XDocument xmlDoc;

        static void Main(string[] args)
        {
            xmlDoc = XDocument.Load("Database\\product.xml");
            string choice;
          
            do
            {
                Console.WriteLine("enter your choice");
                Console.WriteLine("1.Display\n 2.Insert\n 3.Edit\n 4.Delete");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1: display(); break;
                    case 2: insert(); break;
                    case 3: edit(); break;
                    case 4: delete(); break;
                }
                Console.WriteLine("enter 'y' to continue");
                choice = Console.ReadLine();
            } while (choice == "y" || choice == "Y");
            
            Console.ReadLine();
        }

        private static void delete()
        {
            Console.WriteLine("Enter the book title");
            string title = Console.ReadLine();
            var elementsToDelete = from ele in xmlDoc.Elements("Books").Elements("Book")
                                   where ele != null && ele.Attribute("title").Value.Equals(title)
                                   select ele;

            foreach (var e in elementsToDelete)
            {
                e.Remove();

            }
            xmlDoc.Save("Database\\product.xml");
        }

        private static void edit()
        {
            Console.WriteLine("Edit\n 1.title\n 2.author\n 3.year");
            int ch= Convert.ToInt32(Console.ReadLine());
            switch(ch)
            {
                case 1:
                    Console.WriteLine("enter the old title");
                    string title = Console.ReadLine();
                    var items = from item in xmlDoc.Elements("Books").Elements("Book")
                                where item != null && ( item.Attribute("title").Value == title)
                                select item;

                    foreach (var item in items)
                    {

                        Console.WriteLine("enter the new title");
                        string newtitle = Console.ReadLine();

                        //assign new value to the sub-element author
                        item.Attribute("title").Value = newtitle;

                    }
                    break;

                    case 2:
                    Console.WriteLine("enter the old author");
                    string author = Console.ReadLine();
                    var itemz = from it in xmlDoc.Elements("Books").Elements("Book")
                                where it != null && (it.Element("author").Value == author)
                                select it;

                    foreach (var it in itemz)
                    {

                        Console.WriteLine("enter the new title");
                        string newtitle = Console.ReadLine();

                        //assign new value to the sub-element author
                        it.Element("author").Value = newtitle;

                    }
                    break;
                    case 3:
                    Console.WriteLine("enter the old year");
                    string year = Console.ReadLine();
                    var itemyear = from itemsyear in xmlDoc.Elements("Books").Elements("Book")
                                where itemsyear != null && (itemsyear.Element("year").Value == year)
                                select itemsyear;

                    foreach (var itemsyear in itemyear)
                    {

                        Console.WriteLine("enter the new title");
                        string newtitle = Console.ReadLine();

                        //assign new value to the sub-element author
                        itemsyear.Element("year").Value = newtitle;

                    }
                    break;
            }
            xmlDoc.Save("Database\\product.xml");
        }

        private static void display()
        {
            var elements = from ele in xmlDoc.Elements("Books").Elements("Book")
                           where ele != null
                           select ele;

            foreach (var e in elements)
            {
                Console.WriteLine("title:  " + e.Attribute("title").Value);
                Console.WriteLine("author:  " + e.Element("author").Value);
                Console.WriteLine("year:  " + e.Element("year").Value);
                Console.WriteLine("-------------------");


            }

        }

        private static void insert()
        {
            Console.WriteLine("enter the title");
            string title = Console.ReadLine();
            Console.WriteLine("enter the author");
            string author = Console.ReadLine();
            Console.WriteLine("enter the year");
            int year = Convert.ToInt32(Console.ReadLine());

            xmlDoc.Elements("Books").First().Add(new XElement("Book", new XAttribute("title", title), new XElement("author",author), new XElement("year",year )));
             xmlDoc.Save("Database\\product.xml");
        }
    }
}
